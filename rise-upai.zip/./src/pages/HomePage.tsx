import React from 'react';

const HomePage: React.FC = () => {
  const isLoggedIn = !!localStorage.getItem('user_id');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
          Welcome to RiseUp AI
        </h1>
        <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
          Your partner in finding support services and resources
        </p>
        
        {isLoggedIn ? (
          <div className="mt-8 flex justify-center">
            <a
              href="/dashboard"
              className="px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 md:py-4 md:text-lg md:px-10"
            >
              Go to Dashboard
            </a>
          </div>
        ) : (
          <p className="mt-8 text-lg text-gray-600">
            Please log in or sign up to access our services
          </p>
        )}
      </div>

      {/* Features Section */}
      <div className="mt-24">
        <h2 className="text-2xl font-extrabold text-gray-900 text-center">How RiseUp AI Can Help</h2>
        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">Find Shelters</h3>
              <p className="mt-2 text-sm text-gray-500">
                Locate shelters and housing resources near you with our interactive map.
              </p>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">Job Opportunities</h3>
              <p className="mt-2 text-sm text-gray-500">
                Connect with employment opportunities and job training programs.
              </p>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">Skill Development</h3>
              <p className="mt-2 text-sm text-gray-500">
                Access resources to build skills and improve your employment prospects.
              </p>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">AI Assistance</h3>
              <p className="mt-2 text-sm text-gray-500">
                Get personalized support and answers to your questions with our AI chatbot.
              </p>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">Health Resources</h3>
              <p className="mt-2 text-sm text-gray-500">
                Find information about healthcare services and mental health support.
              </p>
            </div>
          </div>

          <div className="bg-white overflow-hidden shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg font-medium text-gray-900">Community Support</h3>
              <p className="mt-2 text-sm text-gray-500">
                Connect with community organizations and support networks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;