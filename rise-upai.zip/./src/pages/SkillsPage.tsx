import React from 'react';

const SkillsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-600 mb-4">Skills Assessment</h1>
      <p className="text-lg text-gray-600 mb-8">Identify your skills and find career opportunities that match your abilities</p>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h2 className="text-xl font-semibold text-blue-600 mb-4">Coming Soon</h2>
        <p className="text-gray-600">
          Our skills assessment tool is currently under development. Check back soon to discover your strengths
          and get personalized career recommendations.
        </p>
      </div>
    </div>
  );
};

export default SkillsPage;