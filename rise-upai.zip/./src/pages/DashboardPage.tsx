import React from 'react';
import { useNavigate } from 'react-router-dom';

const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const username = localStorage.getItem('username');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Welcome, {username || 'User'}</h1>
        <p className="mt-2 text-gray-600">Explore resources and services available to you</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Find Shelters Card */}
        <div className="bg-white p-6 rounded-lg shadow-lg border-2 border-blue-500">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-xl font-semibold text-blue-700">Find Shelters</h3>
              <p className="mt-2 text-gray-700">Locate shelters and housing resources near you</p>
            </div>
            <div className="p-2 bg-blue-100 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
              </svg>
            </div>
          </div>
          <button
            onClick={() => navigate('/resources')}
            className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-md transition-all transform hover:scale-105 hover:shadow-md"
          >
            Find Now
          </button>
        </div>

        {/* Jobs Card */}
        <div 
          onClick={() => navigate('/jobs')}
          className="bg-white hover:bg-gray-50 p-6 rounded-lg shadow-md transition-all cursor-pointer border border-gray-200"
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-medium text-blue-600">Job Opportunities</h3>
              <p className="mt-2 text-gray-600">Find employment and training opportunities</p>
            </div>
            <div className="p-2 bg-blue-100 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
            </div>
          </div>
          <div className="mt-4 text-sm text-blue-600 font-medium">Browse jobs →</div>
        </div>

        {/* Skills Card */}
        <div 
          onClick={() => navigate('/skills')}
          className="bg-white hover:bg-gray-50 p-6 rounded-lg shadow-md transition-all cursor-pointer border border-gray-200"
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-medium text-blue-600">Skills Development</h3>
              <p className="mt-2 text-gray-600">Access resources to build career skills</p>
            </div>
            <div className="p-2 bg-blue-100 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
          </div>
          <div className="mt-4 text-sm text-blue-600 font-medium">Explore skills →</div>
        </div>

        {/* AI Chat Card */}
        <div 
          onClick={() => navigate('/chat')}
          className="bg-white hover:bg-gray-50 p-6 rounded-lg shadow-md transition-all cursor-pointer border border-gray-200"
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-medium text-blue-600">AI Assistant</h3>
              <p className="mt-2 text-gray-600">Get personalized help with our AI assistant</p>
            </div>
            <div className="p-2 bg-blue-100 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
            </div>
          </div>
          <div className="mt-4 text-sm text-blue-600 font-medium">Chat now →</div>
        </div>
      </div>

      {/* Recent Activity Section */}
      <div className="mt-10">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
          <p className="text-gray-600">No recent activity. Start exploring resources to see your activity here.</p>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;