import React from 'react';

const JobsPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-600 mb-4">Job Opportunities</h1>
      <p className="text-lg text-gray-600 mb-8">Find employment opportunities that match your skills and interests</p>
      
      <div className="bg-white p-6 rounded-lg shadow-md mb-8">
        <h2 className="text-xl font-semibold text-blue-600 mb-4">Coming Soon</h2>
        <p className="text-gray-600">
          Our job matching service is currently under development. Check back soon to browse
          employment opportunities tailored to your skills and experience.
        </p>
      </div>
    </div>
  );
};

export default JobsPage;