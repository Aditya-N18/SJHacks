import React, { useState, useEffect } from 'react';
import { resourceApi, Shelter, FindSheltersPayload, PlaceResult } from '../utils/api';
import axios from 'axios';

const API_BASE_URL = 'https://flasktest-m5jd.onrender.com';

const ResourcesPage: React.FC = () => {
  const [shelters, setShelters] = useState<Shelter[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [backendStatus, setBackendStatus] = useState<'checking' | 'connected' | 'error'>('checking');
  const [userCoordinates, setUserCoordinates] = useState<{latitude: number, longitude: number} | null>(null);
  const [geoLocationStatus, setGeoLocationStatus] = useState<'idle' | 'requested' | 'received' | 'error'>('idle');
  const [manualLocation, setManualLocation] = useState('');
  const [searchMethod, setSearchMethod] = useState<'coordinates' | 'manual'>('coordinates');

  // Check backend connectivity on component mount
  useEffect(() => {
    const checkBackendConnection = async () => {
      try {
        await axios.get(API_BASE_URL);
        setBackendStatus('connected');
        console.log('✅ Successfully connected to backend!');
      } catch (err) {
        console.error('❌ Error connecting to backend:', err);
        setBackendStatus('error');
      }
    };

    checkBackendConnection();
    getUserLocation();
  }, []);

  const getUserLocation = () => {
    if (navigator.geolocation) {
      setGeoLocationStatus('requested');
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
          setUserCoordinates(coords);
          setGeoLocationStatus('received');
          console.log('User coordinates retrieved:', coords);
        },
        (error) => {
          console.error('Error getting location:', error);
          setGeoLocationStatus('error');
          setError(`Geolocation error: ${error.message}`);
        }
      );
    } else {
      setGeoLocationStatus('error');
      setError('Geolocation is not supported by this browser.');
    }
  };

  const handleFindShelters = async () => {
    if (searchMethod === 'coordinates' && !userCoordinates) {
      setError('Location coordinates are not available. Please enable location services or use manual location search.');
      return;
    }

    if (searchMethod === 'manual' && !manualLocation.trim()) {
      setError('Please enter a location to search.');
      return;
    }

    setLoading(true);
    setError('');
    setShelters([]);

    try {
      let shelterResults: Shelter[];
      
      if (searchMethod === 'coordinates' && userCoordinates) {
        const payload: FindSheltersPayload = {
          latitude: userCoordinates.latitude,
          longitude: userCoordinates.longitude
        };
        console.log('Searching for shelters at coordinates:', payload);
        shelterResults = await resourceApi.findNearbyShelters(payload);
      } else {
        // Use manual location search
        console.log('Searching for shelters at location:', manualLocation);
        
        const response = await fetch(`${API_BASE_URL}/find_shelters`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            query: manualLocation,
            type: 'shelter'
          }),
        });

        // Log the full response for debugging
        const responseText = await response.text();
        console.log('Raw response:', responseText);
        
        let data;
        try {
          data = JSON.parse(responseText);
          console.log('Parsed response:', data);
        } catch (e) {
          console.error('Error parsing response:', e);
          throw new Error('Invalid response from server');
        }

        if (!response.ok) {
          throw new Error(`Server error: ${response.status} - ${data?.message || 'Unknown error'}`);
        }

        // Convert the response to our Shelter format
        shelterResults = (data.results || []).map((result: PlaceResult): Shelter => ({
          id: result.name.toLowerCase().replace(/\s+/g, '-'),
          name: result.name,
          address: result.formatted_address || result.vicinity || '',
          phone: '',
          distance: '',
          rating: result.rating,
          location: result.geometry?.location
        }));
      }

      console.log('Found shelters:', shelterResults);
      setShelters(shelterResults);
      
      if (shelterResults.length === 0) {
        setError(`No shelters found ${searchMethod === 'coordinates' ? 'near your location' : `in ${manualLocation}`}. Try a different location or search method.`);
      }
    } catch (err) {
      console.error('Error finding shelters:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to find shelters';
      setError(`Error: ${errorMessage}. Please try again or use a different search method.`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-600 mb-8">Find Nearby Shelters</h1>

      {backendStatus === 'checking' && (
        <div className="mb-6 p-4 bg-blue-50 border-l-4 border-blue-400 text-blue-700">
          Checking connection to backend server...
        </div>
      )}

      {backendStatus === 'error' && (
        <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-800">
          <h3 className="font-semibold">Backend Connection Error</h3>
          <p>Could not connect to the backend server at <code className="bg-red-100 px-1 py-0.5 rounded">{API_BASE_URL}</code></p>
          <p className="mt-2 text-sm">Please ensure the server is running and accessible.</p>
        </div>
      )}

      {backendStatus === 'connected' && (
        <div className="space-y-6">
          {/* Search Method Toggle */}
          <div className="flex space-x-4">
            <button
              onClick={() => setSearchMethod('coordinates')}
              className={`px-4 py-2 rounded-lg font-semibold ${
                searchMethod === 'coordinates'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Use My Location
            </button>
            <button
              onClick={() => setSearchMethod('manual')}
              className={`px-4 py-2 rounded-lg font-semibold ${
                searchMethod === 'manual'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Enter Location
            </button>
          </div>

          {/* Search Controls */}
          <div className="flex items-center space-x-4">
            {searchMethod === 'coordinates' ? (
              <>
                <button
                  onClick={handleFindShelters}
                  disabled={loading || geoLocationStatus !== 'received'}
                  className={`px-6 py-2 rounded-lg font-semibold text-white ${
                    loading || geoLocationStatus !== 'received'
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {loading ? 'Searching...' : 'Find Nearby Shelters'}
                </button>
                
                {geoLocationStatus === 'idle' && (
                  <button
                    onClick={getUserLocation}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    Enable Location Services
                  </button>
                )}

                {geoLocationStatus === 'received' && userCoordinates && (
                  <span className="text-green-600">
                    📍 Location found
                  </span>
                )}

                {geoLocationStatus === 'error' && (
                  <span className="text-red-600">
                    ❌ Location error - try entering location manually
                  </span>
                )}
              </>
            ) : (
              <div className="flex-1 flex space-x-4">
                <input
                  type="text"
                  value={manualLocation}
                  onChange={(e) => setManualLocation(e.target.value)}
                  placeholder="Enter city, state, or zip code"
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  onClick={handleFindShelters}
                  disabled={loading || !manualLocation.trim()}
                  className={`px-6 py-2 rounded-lg font-semibold text-white ${
                    loading || !manualLocation.trim()
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {loading ? 'Searching...' : 'Search'}
                </button>
              </div>
            )}
          </div>

          {error && (
            <div className="p-4 bg-red-50 border-l-4 border-red-500 text-red-800">
              {error}
            </div>
          )}

          {shelters.length > 0 && (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {shelters.map((shelter, index) => (
                <div
                  key={shelter.id || index}
                  className="p-4 border rounded-lg shadow-sm hover:shadow-md transition-shadow"
                >
                  <h3 className="text-lg font-semibold text-gray-800">{shelter.name}</h3>
                  <p className="text-gray-600">{shelter.address}</p>
                  {shelter.phone && (
                    <p className="text-gray-600">
                      <span className="font-medium">Phone:</span> {shelter.phone}
                    </p>
                  )}
                  {shelter.distance && (
                    <p className="text-gray-600">
                      <span className="font-medium">Distance:</span> {shelter.distance}
                    </p>
                  )}
                  {shelter.rating && (
                    <div className="mt-2">
                      <span className="font-medium">Rating:</span>{' '}
                      <span className="text-yellow-500">{'★'.repeat(shelter.rating)}</span>
                      <span className="text-gray-300">{'★'.repeat(5 - shelter.rating)}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ResourcesPage;