import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  interactive?: boolean;
  onClick?: () => void;
}

const Card = ({ children, className, interactive = false, onClick }: CardProps) => {
  return (
    <motion.div
      className={cn(
        'bg-white rounded-xl shadow-card p-5 overflow-hidden',
        interactive && 'hover:shadow-card-hover cursor-pointer transition-shadow duration-300',
        className
      )}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={interactive ? { y: -5 } : {}}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
};

export const CardHeader = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <div className={cn('mb-4', className)}>{children}</div>;
};

export const CardTitle = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <h3 className={cn('text-xl font-bold text-neutral-800', className)}>{children}</h3>;
};

export const CardDescription = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <p className={cn('text-neutral-500 mt-1', className)}>{children}</p>;
};

export const CardContent = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <div className={cn('', className)}>{children}</div>;
};

export const CardFooter = ({ children, className }: { children: React.ReactNode; className?: string }) => {
  return <div className={cn('mt-4 pt-4 border-t border-neutral-100', className)}>{children}</div>;
};

export default Card;